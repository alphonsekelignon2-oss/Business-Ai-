BUSINESS IA — GitHub Actions

Place build-apk.yml at:
.github/workflows/build-apk.yml

The Android project must have app/ at the repository root.

Then:
Actions → Build Business IA APK → Run workflow

When it finishes:
open the successful run → Artifacts → BusinessIA-APK
